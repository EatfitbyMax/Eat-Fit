# Observers

The following observer types are supported by the library

```
  Cycling
  HeartRate
  RestingHeartRate
  Running
  StairClimbing
  Walking
  Workout
```
